from flask import Flask, render_template, request, jsonify, session
from azure.storage.blob import BlobServiceClient, BlobClient
import os

app = Flask(__name__)
app.secret_key = ""

# Azure Blob Storage Configuration
AZURE_CONNECTION_STRING = "
RAW_DATA_CONTAINER = 'rawdata'
CLIENT_DATA_CONTAINER = 'clientdata'
RAW_DATA_FILE = 'rawdata.csv'
CLIENT_DATA_FILE = 'clientdata.csv'

# Initialize BlobServiceClient
blob_service_client = BlobServiceClient.from_connection_string(AZURE_CONNECTION_STRING)

ALLOWED_EXTENSIONS = {'xlsx', 'xls', 'csv'}

def allowed_file(filename):
    """Check if the uploaded file is an allowed type."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def upload_form():
    """Render the file upload form."""
    return render_template('new.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    """Handles file upload to replace 'clientdata.csv' in the 'clientdata' container."""
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    if file and allowed_file(file.filename):
        try:
            # Access the clientdata container and the blob
            clientdata_container_client = blob_service_client.get_container_client(CLIENT_DATA_CONTAINER)
            blob_client = clientdata_container_client.get_blob_client(CLIENT_DATA_FILE)
            
            # Upload the new file, overwriting the existing 'clientdata.csv'
            blob_client.upload_blob(file.read(), overwrite=True)
            
            session['previous_file'] = CLIENT_DATA_FILE
            return jsonify({"message": "File successfully uploaded and replaced 'clientdata.csv'!"}), 200

        except Exception as e:
            return jsonify({"error": f"Failed to upload file: {str(e)}"}), 500
    else:
        return jsonify({"error": "Allowed file types are xlsx, xls, csv"}), 400

@app.route('/reset', methods=['POST'])
def reset_data():
    """Handles the reset action by copying 'rawdata.csv' to 'clientdata.csv'."""
    try:
        # Access the rawdata container and the blob
        rawdata_container_client = blob_service_client.get_container_client(RAW_DATA_CONTAINER)
        source_blob_client = rawdata_container_client.get_blob_client(RAW_DATA_FILE)
        
        # Check if the raw data file exists
        if not source_blob_client.exists():
            return jsonify({"error": "Raw data file does not exist in 'rawdata' container"}), 404

        # Download content from 'rawdata.csv'
        source_data = source_blob_client.download_blob().readall()

        # Access the clientdata container and upload the content to 'clientdata.csv'
        clientdata_container_client = blob_service_client.get_container_client(CLIENT_DATA_CONTAINER)
        target_blob_client = clientdata_container_client.get_blob_client(CLIENT_DATA_FILE)
        target_blob_client.upload_blob(source_data, overwrite=True)

        return jsonify({"message": " azure Data reset successfully from 'rawdata.csv' to 'clientdata.csv'!"}), 200

    except Exception as e:
        return jsonify({"error": f"Failed to reset data: {str(e)}"}), 500

if __name__ == "__main__":
    app.run(debug=True)
