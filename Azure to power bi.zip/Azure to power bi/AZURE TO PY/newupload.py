from flask import Flask, render_template, request, jsonify, session
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
import os

app = Flask(__name__)
app.secret_key = "sQEqtQW1o7OmMaPm9QUZev1omdM/8+t+zTs2l5La"

# Azure Blob Storage Configuration
AZURE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=<YOUR_ACCOUNT_NAME>;AccountKey=<YOUR_ACCOUNT_KEY>;EndpointSuffix=core.windows.net"
AZURE_CONTAINER_NAME = 'mycontainer'
BLOB_NAME_CLIENTDATA = 'Clientdata'
BLOB_NAME_RAWDATA = 'Rawdata'

# Initialize BlobServiceClient and ContainerClient
blob_service_client = BlobServiceClient.from_connection_string(AZURE_CONNECTION_STRING)
container_client = blob_service_client.get_container_client(AZURE_CONTAINER_NAME)

ALLOWED_EXTENSIONS = {'xlsx', 'xls', 'csv'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def upload_form():
    return render_template('new.html')

# Route to upload permanent Rawdata
@app.route('/upload_rawdata', methods=['POST'])
def upload_rawdata():
    """Uploads a permanent 'Rawdata' file."""
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    if file and allowed_file(file.filename):
        try:
            # Upload the file to Blob Storage as 'Rawdata'
            blob_client = container_client.get_blob_client(BLOB_NAME_RAWDATA)
            blob_client.upload_blob(file, overwrite=True)
            return jsonify({"message": "Rawdata file uploaded successfully!"}), 200

        except Exception as e:
            return jsonify({"error": f"Failed to upload Rawdata: {str(e)}"}), 500

    return jsonify({"error": "Allowed file types are xlsx, xls, csv"}), 400

# Route to upload Clientdata
@app.route('/upload_clientdata', methods=['POST'])
def upload_clientdata():
    """Handles file upload for 'Clientdata'."""
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    if file and allowed_file(file.filename):
        try:
            # Delete existing Clientdata blob if it exists
            blob_client = container_client.get_blob_client(BLOB_NAME_CLIENTDATA)
            if blob_client.exists():
                blob_client.delete_blob()

            # Upload the new file as 'Clientdata'
            blob_client.upload_blob(file, overwrite=True)

            session['previous_file'] = BLOB_NAME_CLIENTDATA
            return jsonify({"message": "Clientdata file uploaded successfully!"}), 200

        except Exception as e:
            return jsonify({"error": f"Failed to upload Clientdata: {str(e)}"}), 500

    return jsonify({"error": "Allowed file types are xlsx, xls, csv"}), 400

# Route to reset Clientdata from Rawdata
@app.route('/reset', methods=['POST'])
def reset_data():
    """Resets 'Clientdata' by copying from 'Rawdata'."""
    try:
        source_blob_client = container_client.get_blob_client(BLOB_NAME_RAWDATA)
        target_blob_client = container_client.get_blob_client(BLOB_NAME_CLIENTDATA)

        # Check if 'Rawdata' exists before copying
        if not source_blob_client.exists():
            return jsonify({"error": "Rawdata blob does not exist"}), 404

        # Copy content from Rawdata to Clientdata
        source_data = source_blob_client.download_blob().readall()
        target_blob_client.upload_blob(source_data, overwrite=True)

        return jsonify({"message": "Clientdata reset from Rawdata successfully!"}), 200

    except Exception as e:
        return jsonify({"error": f"Failed to reset data: {str(e)}"}), 500

if __name__ == "__main__":
    app.run(debug=True)
